//creating the array and passing the number, question, option and answer
let questions = [

    {
        numb:1,
        question: "HTML stands for?",
        answer: "HyperText Markup Language",
        options: [
                   "HighText Machine Language",
                   "HyperText and links Markup Language",
                   "HyperText Markup Language",
                   "None of these"
                 ]
    },
    {
        numb:2,
        question: "Which of the following element is responsible for making the text bold in HTML?",
        answer: "b tag",
        options: [
                   "pre tag",
                   "a tag",
                   "b tag",
                   "br tag"
                 ]
    },
    {
        numb:3,
        question: "The correct sequence of HTML tags for starting a webpage is -",
        answer: "HTML, Head, Title, Body",
        options: [
                   "Head, Title, HTML, body",
                   "HTML, Body, Title, Head",
                   "HTML, Title, Head, Body",
                   "HTML, Head, Title, Body"
                 ]
    },
    {
        numb:4,
        question: " Which of the following attribute is used to provide a unique name to an element?",
        answer: "id",
        options: [
                   "class",
                   "id",
                   "type",
                   "None of the above"
                 ]
    },
    {
        numb:5,
        question: " A program in HTML can be rendered and read by -",
        answer: "Web browser",
        options: [
                   "Web browser",
                   "Server",
                   "Interpreter",
                   "None of the above"
                 ]
    },
];